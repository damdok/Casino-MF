function CInterface(iCurBet,iTotBet,iMoney){
    var _aLinesBut;
    var _aPayline;
    var _pStartPosAudio;
    var _pStartPosExit;
    var _pStartPosFullscreen;
    
    var _oButExit;
    var _oSpinBut;
    var _oAutoSpinBut;
    var _oInfoBut;
    var _oAddLineBut;
    var _oAudioToggle;
    var _oBetCoinBut;
    var _oMaxBetBut;
    var _oButFullscreen;
    var _fRequestFullScreen = null;
    var _fCancelFullScreen = null;
    
    var _autoSpin = false;
    var _autoSpinInterval;

    var _oCoinText;
    var _oMoneyText;
    var _oTotalBetText;
    var _oNumLinesText;

    var web3Provider = null;
    var contracts = {};
    var balance = 0;
    var account = null;
    var instance = null;
    var machine1 = null;
    var machine2 = null;
    var machine3 = null;
    var started = 0;
    var roll1 = 1;
    var roll2 = -1;
    var roll3 = -1;
    var rolled = false;
    
    this._init = function(iCurBet,iTotBet,iMoney){
        
        var oSprite = s_oSpriteLibrary.getSprite('but_exit');
        _pStartPosExit = {x:CANVAS_WIDTH - (oSprite.width/2) - 10,y:(oSprite.height/2) + 10};
        _oButExit = new CGfxButton(_pStartPosExit.x,_pStartPosExit.y,oSprite,true);
        _oButExit.addEventListener(ON_MOUSE_UP, this._onExit, this);
        
        if(DISABLE_SOUND_MOBILE === false || s_bMobile === false){
            var oSpriteAudio = s_oSpriteLibrary.getSprite('audio_icon');
            _pStartPosAudio = {x: _oButExit.getX() - oSpriteAudio.width/2, y: (oSprite.height/2) + 10};  
            _oAudioToggle = new CToggle(_pStartPosAudio.x,_pStartPosAudio.y,oSpriteAudio,s_bAudioActive,s_oStage);
            _oAudioToggle.addEventListener(ON_MOUSE_UP, this._onAudioToggle, this);
            
            _pStartPosFullscreen = {x:_pStartPosAudio.x - oSpriteAudio.width/2,y:_pStartPosAudio.y};
        }else{
            _pStartPosFullscreen = {x: _oButExit.getX() - oSprite.width, y: (oSprite.height/2) + 10};  
        }
        
        var doc = window.document;
        var docEl = doc.documentElement;
        _fRequestFullScreen = docEl.requestFullscreen || docEl.mozRequestFullScreen || docEl.webkitRequestFullScreen || docEl.msRequestFullscreen;
        _fCancelFullScreen = doc.exitFullscreen || doc.mozCancelFullScreen || doc.webkitExitFullscreen || doc.msExitFullscreen;
        
        if(ENABLE_FULLSCREEN === false){
            _fRequestFullScreen = false;
        }
        
        if (_fRequestFullScreen && screenfull.enabled){
            oSprite = s_oSpriteLibrary.getSprite('but_fullscreen');

            _oButFullscreen = new CToggle(_pStartPosFullscreen.x,_pStartPosFullscreen.y,oSprite,s_bFullscreen,s_oStage);
            _oButFullscreen.addEventListener(ON_MOUSE_UP, this._onFullscreenRelease, this);
        }
        
        oSprite = s_oSpriteLibrary.getSprite('spin_but');
        _oSpinBut = new CTextButton(1190 + (oSprite.width/2),CANVAS_HEIGHT - (oSprite.height/2),oSprite,"",FONT_GAME,"#ffde00",22,s_oStage);  
        _oSpinBut.addEventListener(ON_MOUSE_UP, this._onSpin, this);

        oSprite = s_oSpriteLibrary.getSprite('but_lines_bg');
        _oAutoSpinBut = new CTextButton(990 + (oSprite.width/2),CANVAS_HEIGHT - (oSprite.height/2),oSprite,TEXT_AUTO_SPIN,FONT_GAME,"#ffffff",25,s_oStage);
        _oAutoSpinBut.addEventListener(ON_MOUSE_UP, this._onAutoSpin, this);
        
        
        oSprite = s_oSpriteLibrary.getSprite('info_but');
        _oInfoBut = new CTextButton(228 + (oSprite.width/2),CANVAS_HEIGHT - (oSprite.height/2),oSprite,TEXT_INFO,FONT_GAME,"#ffffff",30,s_oStage);        
        _oInfoBut.addEventListener(ON_MOUSE_UP, this._onInfo, this);
        
        
        oSprite = s_oSpriteLibrary.getSprite('but_lines_bg');
        _oAddLineBut = new CTextButton(394 + (oSprite.width/2),CANVAS_HEIGHT - (oSprite.height/2),oSprite,TEXT_LINES,FONT_GAME,"#ffffff",30,s_oStage);
        _oAddLineBut.addEventListener(ON_MOUSE_UP, this._onAddLine, this);
        
        oSprite = s_oSpriteLibrary.getSprite('coin_but');
        _oBetCoinBut = new CTextButton(580 + (oSprite.width/2),CANVAS_HEIGHT - (oSprite.height/2),oSprite,TEXT_COIN,FONT_GAME,"#ffffff",30,s_oStage);
        _oBetCoinBut.addEventListener(ON_MOUSE_UP, this._onBet, this);
        
        oSprite = s_oSpriteLibrary.getSprite('but_maxbet_bg');
        _oMaxBetBut = new CTextButton(766 + (oSprite.width/2),CANVAS_HEIGHT - (oSprite.height/2),oSprite,TEXT_MAX_BET,FONT_GAME,"#ffffff",30,s_oStage);
        _oMaxBetBut.addEventListener(ON_MOUSE_UP, this._onMaxBet, this);
		
	_oMoneyText = new createjs.Text(TEXT_MONEY +"\n"+iMoney.toFixed(2)+ TEXT_CURRENCY,"30px "+FONT_GAME, "#ffde00");
        _oMoneyText.x = 450;
        _oMoneyText.y = 46;
        _oMoneyText.textBaseline = "alphabetic";
        _oMoneyText.lineHeight = 28;
        _oMoneyText.textAlign = "center";
        s_oStage.addChild(_oMoneyText);
        
        _oNumLinesText = new createjs.Text(NUM_PAYLINES ,"26px "+FONT_GAME, "#ffffff");
        _oNumLinesText.x =  484;
        _oNumLinesText.y = CANVAS_HEIGHT - 65;
        _oNumLinesText.shadow = new createjs.Shadow("#000", 2, 2, 2);
        _oNumLinesText.textAlign = "center";
        _oNumLinesText.textBaseline = "alphabetic";
        s_oStage.addChild(_oNumLinesText);
        
        _oCoinText = new createjs.Text(iCurBet.toFixed(2) ,"26px "+FONT_GAME, "#ffffff");
        _oCoinText.x =  676;
        _oCoinText.y = CANVAS_HEIGHT - 65;
        _oCoinText.shadow = new createjs.Shadow("#000", 2, 2, 2);
        _oCoinText.textAlign = "center";
        _oCoinText.textBaseline = "alphabetic";
        s_oStage.addChild(_oCoinText);

        _oTotalBetText = new createjs.Text(TEXT_BET +": "+iTotBet.toFixed(2),"26px "+FONT_GAME, "#ffffff");
        _oTotalBetText.x = 880;
        _oTotalBetText.y = CANVAS_HEIGHT - 65;
        _oTotalBetText.shadow = new createjs.Shadow("#000", 2, 2, 2);
        _oTotalBetText.textAlign = "center";
        _oTotalBetText.textBaseline = "alphabetic";
        s_oStage.addChild(_oTotalBetText);
        
        oSprite = s_oSpriteLibrary.getSprite('bet_but');
        _aLinesBut = new Array();
        
        //LINE 1
        oSprite = s_oSpriteLibrary.getSprite('sunflower_1');
        var oBut = new CBetBut( 334 + oSprite.width/2, 282 + oSprite.height/2,oSprite);
        oBut.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this,1);
        _aLinesBut[0] = oBut;
        
        //LINE 2
        oSprite = s_oSpriteLibrary.getSprite('sunflower_2');
        oBut = new CBetBut( 334 + oSprite.width/2, 180 + oSprite.height/2,oSprite);
        oBut.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this,2);
        _aLinesBut[1] = oBut;
        
        //LINE 3
        oSprite = s_oSpriteLibrary.getSprite('sunflower_3');
        oBut = new CBetBut( 334 + oSprite.width/2, 432 + oSprite.height/2,oSprite);
        oBut.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this,3);
        _aLinesBut[2] = oBut;
        
        //LINE 4
        oSprite = s_oSpriteLibrary.getSprite('sunflower_4');
        oBut = new CBetBut( 334 + oSprite.width/2, 114 + oSprite.height/2,oSprite);
        oBut.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this,4);
        _aLinesBut[3] = oBut;

        //LINE 5
        oSprite = s_oSpriteLibrary.getSprite('sunflower_5');
        oBut = new CBetBut( 334 + oSprite.width/2, 502 + oSprite.height/2,oSprite);
        oBut.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this,5);
        _aLinesBut[4] = oBut;

        _aPayline = new Array();
        for(var k = 0;k<NUM_PAYLINES;k++){
            var oBmp = new createjs.Bitmap(s_oSpriteLibrary.getSprite('payline_'+(k+1) ));
            oBmp.visible = false;
            s_oStage.addChild(oBmp);
            _aPayline[k] = oBmp;
        }
        
        this.refreshButtonPos(s_iOffsetX,s_iOffsetY);
        this.initWeb3();
    };

    this.initWeb3 = function() {
        if (typeof web3 !== 'undefined') {
            web3Provider = web3.currentProvider;
            web3 = new Web3(web3.currentProvider);
        } else {
            // set the provider you want from Web3.providers
            web3Provider = new Web3.providers.HttpProvider('http://localhost:8545');
            web3 = new Web3(web3Provider);
            toastr.warning('You need MetaMask extension or Parity to use this app.');
    
        }

        this.initContract();
    }

    this.initContract = function() {
        $.getJSON('../build/contracts/SlotMachine.json', function(data) {
            // Get the necessary contract artifact file and instantiate it with truffle-contract.
            var SlotMachineArtifact = data;
      
            try {
               contracts.SlotMachine = TruffleContract(SlotMachineArtifact);
      
              // Set the provider for our contract.
              contracts.SlotMachine.setProvider(web3Provider);
      
              checkAccount();
              //App.slotMachine();
            } catch(err) {
                console.log(err);
            }
      
          });
      
          //return App.bindEvents();
    }

    function checkAccount() {
        web3.eth.getAccounts(function(error, accounts) {
            account = accounts[0];
            contracts.SlotMachine.deployed().then(function(_instance) {
                instance = _instance;
    
                var event = instance.Rolled();
    
                 event.watch(function(err, resp) {
                     if(resp.event === "Rolled") {
    
                        //  $("#slotMachineButtonStop").attr("disabled", false);
                        //  $("#slotMachineButtonStop").attr("title", "");
                        //  $("#header-msg").text("Luck favors the bold!");
    
                         roll1 = resp.args.rand1.valueOf();
                         roll2 = resp.args.rand2.valueOf();
                         roll3 = resp.args.rand3.valueOf();
    
                         rolled = true;
    
                         console.log(roll1, roll2, roll3);
    
                         toastr.success('Go ahead!', 'Press Stop to find out if you won');
    
                         //setTimeout(App.checkBalance, 1000);
                     }
                 });
    
                checkBalance();
            })
            .catch(function(err) {
                toastr.warning('Make sure you are connected to Ropsten network');
            });
        });
    }

    function checkBalance() {
        instance.balanceOf.call(account).then(function(_balance) {

            balance = _balance.valueOf();
    
            var balanceInEther = web3.fromWei(balance, "ether");
            // $("#balance").text(balanceInEther + " ether");
            
        });
    }
    
    this.unload = function(){
        _oButExit.unload();
        _oButExit = null;
        _oSpinBut.unload();
        _oSpinBut = null;
        _oInfoBut.unload();
        _oInfoBut = null;
        _oAddLineBut.unload();
        _oAddLineBut = null;
        _oBetCoinBut.unload();
        _oBetCoinBut = null;
        _oMaxBetBut.unload();
        _oMaxBetBut = null;
        
        if(DISABLE_SOUND_MOBILE === false || s_bMobile === false){
            _oAudioToggle.unload();
            _oAudioToggle = null;
        }
        
        if (_fRequestFullScreen && screenfull.enabled){
            _oButFullscreen.unload();
        }
        
        for(var i=0;i<NUM_PAYLINES;i++){
            _aLinesBut[i].unload();
        }
        
        s_oStage.removeAllChildren();
        s_oInterface = null;
    };
    
    this.refreshButtonPos = function(iNewX,iNewY){
        if(DISABLE_SOUND_MOBILE === false || s_bMobile === false){
            _oAudioToggle.setPosition(_pStartPosAudio.x - iNewX,iNewY + _pStartPosAudio.y);
        }
        
        if (_fRequestFullScreen && screenfull.enabled){
            _oButFullscreen.setPosition(_pStartPosFullscreen.x - iNewX,_pStartPosFullscreen.y + iNewY);
        }
        
        _oButExit.setPosition(_pStartPosExit.x - iNewX,iNewY + _pStartPosExit.y);
    };

    this.refreshMoney = function(iMoney){
        _oMoneyText.text = TEXT_MONEY +"\n"+iMoney.toFixed(2) + TEXT_CURRENCY;
    };
    
    this.refreshBet = function(iBet){
        _oCoinText.text = iBet.toFixed(2);
    };
    
    this.refreshTotalBet = function(iTotBet){
        _oTotalBetText.text = TEXT_BET +": "+iTotBet.toFixed(2);
    };
    
    this.refreshNumLines = function(iLines){
        _oNumLinesText.text = iLines;
        
        for(var i=0;i<NUM_PAYLINES;i++){
            if(i<iLines){
                //_aLinesBut[i].setOn();
                _aPayline[i].visible = true;
            }else{
                _aLinesBut[i].setOff();
            }
        }
        
        setTimeout(function(){for(var i=0;i<NUM_PAYLINES;i++){
            _aPayline[i].visible = false;
        }},1000);
    };
    
    this.resetWin = function(){
        _oSpinBut.changeText("");
    };
    
    this.refreshWinText = function(iWin){
        _oSpinBut.changeText(TEXT_WIN + "\n"+iWin.toFixed(2));
    };
    
    this.showLine = function(iLine){
        _aPayline[iLine-1].visible = true;
    };
    
    this.hideLine = function(iLine){
        _aPayline[iLine-1].visible = false;
    };
    
    this.hideAllLines = function(){
        for(var i=0;i<NUM_PAYLINES;i++){
            _aPayline[i].visible = false;
        }
    };
    
    this.disableBetBut = function(bDisable){
        for(var i=0;i<NUM_PAYLINES;i++){
            _aLinesBut[i].disable(bDisable);
        }
    };
    
    this.enableGuiButtons = function(){
        _oSpinBut.enable();
        _oMaxBetBut.enable();
        _oBetCoinBut.enable();
        _oAddLineBut.enable();
        _oInfoBut.enable();
    };
	
    this.enableSpin = function(){
            _oSpinBut.enable();
            _oMaxBetBut.enable();
    };

    this.disableSpin = function(){
            _oSpinBut.disable();
            _oMaxBetBut.disable();
    };
    
    this.enableMaxBet = function(){
        _oMaxBetBut.enable();
    };
    
    this.disableMaxBet = function(){
        _oMaxBetBut.disable();
    };
    
    this.disableGuiButtons = function(){
        _oSpinBut.disable();
        _oMaxBetBut.disable();
        _oBetCoinBut.disable();
        _oAddLineBut.disable();
        _oInfoBut.disable();
    };
    
    this._onBetLineClicked = function(iLine){
        this.refreshNumLines(iLine);
        
        s_oGame.activateLines(iLine);
    };
    
    this._onExit = function(){
        s_oGame.onExit();  
    };
    
    this._onSpin = function(){
        s_oGame.onSpin();
        this.startRoll();
    };

    this.startRoll = function() {
        event.preventDefault();

        if(started != 0) {
            return;
        }

        contracts.SlotMachine.deployed().then(function(instance) {

            instance.oneRoll.sendTransaction({from: account, value: web3.toWei('0.1', 'ether')});
    
        }).then(function() {
            //App.startShuffle();
        })
        .catch(function(err) {
            toastr.warning('Make sure you are connected to Ropsten network');
        });
    }

    this.onSpin2 = function() {
        s_oGame.onSpin();
    };
    
    this._onAutoSpin = function(){
        _autoSpin = !_autoSpin;
        if(_autoSpin) {
            this._onSpin();
            _autoSpinInterval = setInterval(this.onSpin2, 6000);
       } else {
            clearInterval( _autoSpinInterval );
       }
    };
    
    this._onAddLine = function(){
        s_oGame.addLine();
    };
    
    this._onInfo = function(){
        s_oGame.onInfoClicked();
    };
    
    this._onBet = function(){
        s_oGame.changeCoinBet();
    };
    
    this._onMaxBet = function(){
        s_oGame.onMaxBet();
    };
    
    this._onAudioToggle = function(){
        Howler.mute(s_bAudioActive);
        s_bAudioActive = !s_bAudioActive;
    };
    
    this.resetFullscreenBut = function(){
	if (_fRequestFullScreen && screenfull.enabled){
		_oButFullscreen.setActive(s_bFullscreen);
	}
    };


    this._onFullscreenRelease = function(){
	if(s_bFullscreen) { 
		_fCancelFullScreen.call(window.document);
	}else{
		_fRequestFullScreen.call(window.document.documentElement);
	}
	
	sizeHandler();
    };
    
    s_oInterface = this;
    
    this._init(iCurBet,iTotBet,iMoney);
    
    return this;
}

var s_oInterface = null;