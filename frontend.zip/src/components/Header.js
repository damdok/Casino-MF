import React from 'react'
import { makeStyles } from '@material-ui/core/styles'
const useStyles = makeStyles(theme => ({
  alignItemsAndJustifyContent: {
    display: 'flex',
    textAlign: 'center',
    justifyContent: 'center',
    backgroundColor: '#ffc107',
    fontWeight:"bold",
    color:"white",
    fontSize:"35px",
    padding:"15px"
  },
}))
const Header = () => {
  const classes = useStyles()
  return (
    <React.Fragment>
      <div className={classes.alignItemsAndJustifyContent}>
        Welcome to Princess Nandika’s world
      </div>
    </React.Fragment>
  )
}

export default Header