import React from 'react'
import CssBaseline from '@material-ui/core/CssBaseline';
import Container from '@material-ui/core/Container';

function NotFound() {
    return (
            <React.Fragment>
                <CssBaseline />
                <Container>
                    <div>
                        <center>
                            <h1>Error 404 Page Not Found</h1>
                            <p>The page you are looking for is not available. Sorry!</p>
                        </center>
                    </div>
                </Container>
            </React.Fragment>
    )
}

export default NotFound;
