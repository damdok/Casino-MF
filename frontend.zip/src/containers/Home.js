import React from 'react';
import Particle from './Particle';

const Home = () => {
  return (
    <React.Fragment>
      <Particle />
    </React.Fragment>
  );
}

export default Home;